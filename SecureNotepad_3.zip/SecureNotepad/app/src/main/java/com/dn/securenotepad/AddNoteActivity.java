package com.dn.securenotepad;
import android.os.*;
import androidx.appcompat.widget.*;
import android.view.*;
import org.json.*;
import java.text.*;
import java.util.*;

public class AddNoteActivity extends BaseActivity
{
	LinedEditText noteField;

	@Override
	protected void onCreate(Bundle savedInstanceState)
	{
		// TODO: Implement this method
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_add_note);
		setTitle(R.string.add_note);
		setSupportActionBar((Toolbar)findViewById(R.id.toolbar));
		getSupportActionBar().setDisplayHomeAsUpEnabled(true);
		noteField = findViewById(R.id.note);
	}
	
	public void save() {
		final String note = noteField.getText().toString();
		if (note.trim().equals("")) {
			finish();
			return;
		}
		try {
			JSONArray notesJSON = new JSONArray(read("notes", "[]").trim());
			JSONObject noteJSON = new JSONObject();
			noteJSON.put("uuid", UUID.randomUUID().toString());
			noteJSON.put("note", note);
			noteJSON.put("date", new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(new Date()));
			notesJSON.put(noteJSON);
			write("notes", notesJSON.toString());
			setResult(RESULT_OK);
			finish();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu)
	{
		// TODO: Implement this method
		getMenuInflater().inflate(R.menu.add_note, menu);
		return true;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item)
	{
		// TODO: Implement this method
		int id = item.getItemId();
		if (id == android.R.id.home) {
			save();
		} else if (id == R.id.save) {
			save();
		}
		return false;
	}

	@Override
	public void onBackPressed()
	{
		// TODO: Implement this method
		save();
	}
}
