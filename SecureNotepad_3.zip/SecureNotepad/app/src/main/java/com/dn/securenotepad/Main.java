package com.dn.securenotepad;

import android.app.*;
import android.os.*;
import android.*;
import android.content.pm.*;
import android.content.*;

public class Main extends BaseActivity 
{
	String[] permissions = {
		Manifest.permission.WRITE_EXTERNAL_STORAGE,
		Manifest.permission.CAMERA
	};
	
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        if (Build.VERSION.SDK_INT >= 23) {
			if (checkSelfPermission(permissions[0]) != PackageManager.PERMISSION_GRANTED
				|| checkSelfPermission(permissions[1]) != PackageManager.PERMISSION_GRANTED) {
				requestPermissions(permissions, 1);
			} else {
				init();
			}
		} else {
			init();
		}
    }
	
	public void init() {
		startActivity(new Intent(this, HomeActivity.class));
		finish();
	}

	@Override
	public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults)
	{
		// TODO: Implement this method
		super.onRequestPermissionsResult(requestCode, permissions, grantResults);
		if (requestCode == 1) {
			boolean granted = true;
			for (int result:grantResults) {
				if (result != PackageManager.PERMISSION_GRANTED) {
					granted = false;
					break;
				}
			}
			if (granted) {
				init();
			} else {
				finish();
			}
		}
	}
	
	public void test() {}
}
