package com.dn.securenotepad.adapter;

import androidx.appcompat.widget.*;

import android.view.*;
import android.content.*;

import java.util.*;

import org.json.*;
import org.w3c.dom.Document;

import com.dn.securenotepad.R;

import android.widget.*;

import java.io.*;

import com.dn.securenotepad.*;
import com.dn.securenotepad.fragments.DocumentFragment;

import android.net.*;

import androidx.appcompat.app.*;

import android.app.ProgressDialog;

import androidx.core.content.*;

import android.text.*;

import androidx.recyclerview.widget.RecyclerView;

public class DocumentAdapter extends RecyclerView.Adapter<DocumentAdapter.ViewHolder> {
    public Context context;
    public ArrayList<JSONObject> documents;
    public DocumentFragment documentFragment;

    public DocumentAdapter(Context ctx, ArrayList<JSONObject> documents, DocumentFragment documentFragment) {
        this.context = ctx;
        this.documents = documents;
        this.documentFragment = documentFragment;
    }

    @Override
    public DocumentAdapter.ViewHolder onCreateViewHolder(ViewGroup parent, int p2) {
        // TODO: Implement this method
        return new ViewHolder(LayoutInflater.from(context).inflate(R.layout.document, parent, false));
    }

    @Override
    public void onBindViewHolder(DocumentAdapter.ViewHolder holder, final int position) {
        // TODO: Implement this method
        try {
            final JSONObject document = documents.get(position);
            final String path = Util.getString(document, "path", "").trim();
            holder.select.setOnClickListener(new View.OnClickListener() {

                @Override
                public void onClick(View view) {
                    new AlertDialog.Builder(context)
                            .setItems(new String[]{
                                    context.getResources().getString(R.string.view),
                                    context.getResources().getString(R.string.restore),
                                    context.getResources().getString(R.string.delete)
                            }, new DialogInterface.OnClickListener() {

                                @Override
                                public void onClick(DialogInterface dialogInterface, int pos) {
                                    if (pos == 0) {
                                        final ProgressDialog dialog = Util.createDialog(context, R.string.processing);
                                        dialog.show();
                                        Util.run(new Runnable() {

                                            @Override
                                            public void run() {
                                                try {
                                                    FileInputStream fis = new FileInputStream(new File(path));
                                                    ByteArrayOutputStream baos = new ByteArrayOutputStream();
                                                    int read;
                                                    byte[] buffer = new byte[8192];
                                                    while ((read = fis.read(buffer)) != -1) {
                                                        baos.write(buffer, 0, read);
                                                    }
                                                    baos.flush();
                                                    byte[] encryptedData = baos.toByteArray();
                                                    baos.close();
                                                    fis.close();
                                                    byte[] encodedData = Util.decrypt(encryptedData);
                                                    byte[] data = Util.decodeToByteArray(encodedData);
                                                    final File tmpDocumentFile = new File(context.getFilesDir(), "Document");
                                                    FileOutputStream fos = new FileOutputStream(tmpDocumentFile);
                                                    fos.write(data, 0, data.length);
                                                    fos.flush();
                                                    fos.close();
                                                    Util.runLater(new Runnable() {

                                                        @Override
                                                        public void run() {
                                                            dialog.dismiss();
                                                            Uri uri = FileProvider.getUriForFile(context, context.getPackageName() + ".fileprovider", tmpDocumentFile);
                                                            String mime = Util.getString(document, "mime_type", "").trim();
                                                            Intent intent = new Intent();
                                                            intent.setAction(Intent.ACTION_VIEW);
                                                            intent.setDataAndType(uri, mime);
                                                            intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                                                            context.startActivity(intent);
                                                        }
                                                    });
                                                } catch (final Exception e) {
                                                    e.printStackTrace();
                                                    Util.runLater(new Runnable() {

                                                        @Override
                                                        public void run() {
                                                            Util.show(context, e.getMessage());
                                                        }
                                                    });
                                                }
                                            }
                                        });
										/*final String currentPassword = Util.readEncrypted(context, "password", "").trim();
										if (currentPassword.equals("")) {
											new AlertDialog.Builder(context)
												.setMessage(R.string.text5)
												.setPositiveButton(R.string.ok, new DialogInterface.OnClickListener() {

													@Override
													public void onClick(DialogInterface p1, int p2)
													{
														// TODO: Implement this method
														((HomeActivity)context).setupPassword();
													}
												})
												.create()
												.show();
											return;
										}
										View view = LayoutInflater.from(context).inflate(R.layout.enter_password, null);
										final AlertDialog dialog = new AlertDialog.Builder(context)
											.setView(view)
											.setPositiveButton(R.string.cancel, null)
											.create();
										final EditText passwordField = view.findViewById(R.id.password);
										passwordField.addTextChangedListener(new TextWatcher() {

												@Override
												public void beforeTextChanged(CharSequence p1, int p2, int p3, int p4)
												{
													// TODO: Implement this method
												}

												@Override
												public void onTextChanged(CharSequence p1, int p2, int p3, int p4)
												{
													// TODO: Implement this method
													final String password = passwordField.getText().toString().trim();
													if (password.startsWith("*") && password.endsWith("#")) {
														dialog.dismiss();
														if (currentPassword.equals(password)) {
															final ProgressDialog dialog = Util.createDialog(context, R.string.processing);
															dialog.show();
															Util.run(new Runnable() {

																	@Override
																	public void run() {
																		try {
																			FileInputStream fis = new FileInputStream(new File(path));
																			ByteArrayOutputStream baos = new ByteArrayOutputStream();
																			int read;
																			byte[] buffer = new byte[8192];
																			while ((read = fis.read(buffer)) != -1) {
																				baos.write(buffer, 0, read);
																			}
																			baos.flush();
																			byte[] encryptedData = baos.toByteArray();
																			baos.close();
																			fis.close();
																			byte[] encodedData = Util.decrypt(encryptedData);
																			byte[] data = Util.decodeToByteArray(encodedData);
																			final File tmpDocumentFile = new File(context.getFilesDir(), "Document");
																			FileOutputStream fos = new FileOutputStream(tmpDocumentFile);
																			fos.write(data, 0, data.length);
																			fos.flush();
																			fos.close();
																			Util.runLater(new Runnable() {

																					@Override
																					public void run() {
																						dialog.dismiss();
																						Uri uri = FileProvider.getUriForFile(context, context.getPackageName() + ".fileprovider", tmpDocumentFile);
																						String mime = Util.getString(document, "mime_type", "").trim();
																						Intent intent = new Intent();
																						intent.setAction(Intent.ACTION_VIEW);
																						intent.setDataAndType(uri, mime);
																						intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
																						context.startActivity(intent);
																					}
																				});
																		} catch (final Exception e) {
																			e.printStackTrace();
																			Util.runLater(new Runnable() {

																					@Override
																					public void run() {
																						Util.show(context, e.getMessage());
																					}
																				});
																		}
																	}
																});
														} else {
															Util.show(context, R.string.text13);
														}
													}
												}

												@Override
												public void afterTextChanged(Editable p1)
												{
													// TODO: Implement this method
												}
											});
										dialog.show();*/
                                    } else if (pos == 1) {
                                        new AlertDialog.Builder(context)
                                                .setMessage(R.string.text16)
                                                .setPositiveButton(R.string.yes, new DialogInterface.OnClickListener() {

                                                    @Override
                                                    public void onClick(DialogInterface p1, int p2)
                                                    {
                                                        // TODO: Implement this method
                                                        final String currentPassword = Util.readEncrypted(context, "password", "").trim();
                                                        if (currentPassword.equals("")) {
                                                            new AlertDialog.Builder(context)
                                                                    .setMessage(R.string.text5)
                                                                    .setPositiveButton(R.string.ok, new DialogInterface.OnClickListener() {

                                                                        @Override
                                                                        public void onClick(DialogInterface p1, int p2)
                                                                        {
                                                                            // TODO: Implement this method
                                                                            ((HomeActivity)context).setupPassword();
                                                                        }
                                                                    })
                                                                    .create()
                                                                    .show();
                                                            return;
                                                        }
                                                        View view = LayoutInflater.from(context).inflate(R.layout.enter_password, null);
                                                        final AlertDialog dialog = new AlertDialog.Builder(context)
                                                                .setView(view)
                                                                .setPositiveButton(R.string.cancel, null)
                                                                .create();
                                                        final EditText passwordField = view.findViewById(R.id.password);
                                                        passwordField.addTextChangedListener(new TextWatcher() {

                                                            @Override
                                                            public void beforeTextChanged(CharSequence p1, int p2, int p3, int p4)
                                                            {
                                                                // TODO: Implement this method
                                                            }

                                                            @Override
                                                            public void onTextChanged(CharSequence p1, int p2, int p3, int p4)
                                                            {
                                                                // TODO: Implement this method
                                                                final String password = passwordField.getText().toString().trim();
                                                                if (password.startsWith("*") && password.endsWith("#")) {
                                                                    dialog.dismiss();
                                                                    if (currentPassword.equals(password)) {
                                                                        documentFragment.save(position, document);
                                                                    } else {
                                                                        Util.show(context, R.string.text13);
                                                                    }
                                                                }
                                                            }

                                                            @Override
                                                            public void afterTextChanged(Editable p1)
                                                            {
                                                                // TODO: Implement this method
                                                            }
                                                        });
                                                        dialog.show();
                                                    }
                                                })
                                                .setNegativeButton(R.string.no, null)
                                                .create()
                                                .show();
                                    } else if (pos == 2) {
                                        new AlertDialog.Builder(context)
                                                .setMessage(R.string.text18)
                                                .setPositiveButton(R.string.yes, new DialogInterface.OnClickListener() {

                                                    @Override
                                                    public void onClick(DialogInterface p1, int p2) {
                                                        // TODO: Implement this method
                                                        final String currentPassword = Util.readEncrypted(context, "password", "").trim();
                                                        if (currentPassword.equals("")) {
                                                            new AlertDialog.Builder(context)
                                                                    .setMessage(R.string.text5)
                                                                    .setPositiveButton(R.string.ok, new DialogInterface.OnClickListener() {

                                                                        @Override
                                                                        public void onClick(DialogInterface p1, int p2) {
                                                                            // TODO: Implement this method
                                                                            ((HomeActivity) context).setupPassword();
                                                                        }
                                                                    })
                                                                    .create()
                                                                    .show();
                                                            return;
                                                        }
                                                        View view = LayoutInflater.from(context).inflate(R.layout.enter_password, null);
                                                        final AlertDialog dialog = new AlertDialog.Builder(context)
                                                                .setView(view)
                                                                .setPositiveButton(R.string.cancel, null)
                                                                .create();
                                                        final EditText passwordField = view.findViewById(R.id.password);
                                                        passwordField.addTextChangedListener(new TextWatcher() {

                                                            @Override
                                                            public void beforeTextChanged(CharSequence p1, int p2, int p3, int p4) {
                                                                // TODO: Implement this method
                                                            }

                                                            @Override
                                                            public void onTextChanged(CharSequence p1, int p2, int p3, int p4) {
                                                                // TODO: Implement this method
                                                                final String password = passwordField.getText().toString().trim();
                                                                if (password.startsWith("*") && password.endsWith("#")) {
                                                                    dialog.dismiss();
                                                                    if (currentPassword.equals(password)) {
                                                                        documents.remove(position);
                                                                        notifyItemRemoved(position);
                                                                        try {
                                                                            JSONArray documentsJSON = new JSONArray();
                                                                            for (JSONObject document : documents) {
                                                                                documentsJSON.put(document);
                                                                            }
                                                                            Util.write(context, "documents", documentsJSON.toString());
                                                                        } catch (Exception e) {
                                                                            e.printStackTrace();
                                                                        }
                                                                    } else {
                                                                        Util.show(context, R.string.text13);
                                                                    }
                                                                }
                                                            }

                                                            @Override
                                                            public void afterTextChanged(Editable p1) {
                                                                // TODO: Implement this method
                                                            }
                                                        });
                                                        dialog.show();
                                                    }
                                                })
                                                .setNegativeButton(R.string.no, null)
                                                .create()
                                                .show();
                                    }
                                }
                            })
                            .create()
                            .show();
                }
            });
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public int getItemCount() {
        // TODO: Implement this method
        return documents.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        public LinearLayout select;

        public ViewHolder(View view) {
            super(view);
            select = view.findViewById(R.id.select);
        }
    }

    public void b() {
    }
}
