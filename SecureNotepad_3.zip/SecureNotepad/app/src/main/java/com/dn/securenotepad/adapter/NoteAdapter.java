package com.dn.securenotepad.adapter;

import androidx.appcompat.widget.*;
import android.view.*;
import java.util.*;
import org.json.*;
import android.content.*;
import com.dn.securenotepad.R;
import android.widget.*;
import com.dn.securenotepad.*;
import java.text.*;
import android.view.View.*;
import androidx.appcompat.app.*;
import androidx.recyclerview.widget.RecyclerView;

public class NoteAdapter extends RecyclerView.Adapter<NoteAdapter.ViewHolder>
{
	Context context;
	ArrayList<JSONObject> notes;
	Listener listener;
	
	public NoteAdapter(Context ctx, ArrayList<JSONObject> notes, Listener listener) {
		this.context = ctx;
		this.notes = notes;
		this.listener = listener;
	}

	@Override
	public NoteAdapter.ViewHolder onCreateViewHolder(ViewGroup parent, int p2)
	{
		// TODO: Implement this method
		return new ViewHolder(LayoutInflater.from(context).inflate(R.layout.note, parent, false));
	}

	@Override
	public void onBindViewHolder(NoteAdapter.ViewHolder holder, final int pos)
	{
		// TODO: Implement this method
		final JSONObject noteJSON = notes.get(pos);
		String note = Util.getString(noteJSON, "note", "").trim();
		if (note.length() > 150) {
			note = note.substring(0, 150);
		}
		holder.noteView.setText(note);
		try {
			holder.dateView.setText(
				new SimpleDateFormat("d MMMM yyyy HH:mm:ss").format(
					new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").parse(Util.getString(noteJSON, "date", "").trim()).getTime()));
		} catch (Exception e) {
			e.printStackTrace();
		}
		holder.select.setOnClickListener(new OnClickListener() {

				@Override
				public void onClick(View view) {
					if (listener != null) {
						listener.onSelected(pos, noteJSON);
					}
				}
		});
	}

	@Override
	public int getItemCount()
	{
		// TODO: Implement this method
		return notes.size();
	}
	
	public class ViewHolder extends RecyclerView.ViewHolder {
		public LinearLayout select;
		public TextView noteView, dateView;
		
		public ViewHolder(View view) {
			super(view);
			select = view.findViewById(R.id.select);
			noteView = view.findViewById(R.id.note);
			dateView = view.findViewById(R.id.date);
		}
	}
	
	public interface Listener {
		
		void onSelected(int pos, JSONObject note);
	}
}
