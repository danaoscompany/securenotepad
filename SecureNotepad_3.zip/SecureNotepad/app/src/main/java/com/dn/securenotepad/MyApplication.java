package com.dn.securenotepad;

import android.app.*;

public class MyApplication extends Application
{

	@Override
	public void onCreate()
	{
		// TODO: Implement this method
		super.onCreate();
	}
	
	public void b() {}
}
