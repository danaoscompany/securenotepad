package com.dn.securenotepad.home_fragments;

import android.os.*;
import androidx.appcompat.widget.*;
import android.view.*;

import androidx.core.view.*;
import com.dn.securenotepad.adapter.*;
import com.dn.securenotepad.fragments.*;

import androidx.core.content.*;
import androidx.appcompat.app.*;
import androidx.core.app.*;
import androidx.fragment.app.Fragment;
import androidx.viewpager.widget.ViewPager;

import com.dn.securenotepad.*;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.tabs.TabLayout;

public class HomeFragment extends Fragment
{
	View view;
	HomeActivity activity;
	TabLayout tabs;
	ViewPager viewPager;
	ViewPagerAdapter adapter;
	PhotoFragment photoFragment;
	VideoFragment videoFragment;
	DocumentFragment documentFragment;
	FloatingActionButton add;

	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState)
	{
		// TODO: Implement this method
		view = inflater.inflate(R.layout.fragment_home, container, false);
		return view;
	}

	@Override
	public void onActivityCreated(Bundle savedInstanceState)
	{
		// TODO: Implement this method
		super.onActivityCreated(savedInstanceState);
		activity = (HomeActivity)getActivity();
		tabs = view.findViewById(R.id.tabs);
		viewPager = view.findViewById(R.id.viewpager);
		add = view.findViewById(R.id.add);
		add.setOnClickListener(new View.OnClickListener() {

				@Override
				public void onClick(View view)
				{
					// TODO: Implement this method
					add(view);
				}
		});
		adapter = new ViewPagerAdapter(activity, getChildFragmentManager());
		photoFragment = new PhotoFragment();
		videoFragment = new VideoFragment();
		documentFragment = new DocumentFragment();
		adapter.add(photoFragment, R.string.photo);
		adapter.add(videoFragment, R.string.video);
		adapter.add(documentFragment, R.string.document);
		viewPager.setAdapter(adapter);
		tabs.setupWithViewPager(viewPager);
	}
	
	public void add(View view)
	{
		if (viewPager.getCurrentItem() == 0)
		{
			photoFragment.add();
		}
		else if (viewPager.getCurrentItem() == 1)
		{
			videoFragment.add();
		}
		else if (viewPager.getCurrentItem() == 2)
		{
			documentFragment.add();
		}
	}
}
