package com.dn.securenotepad;
import android.app.*;
import android.os.*;

import androidx.appcompat.app.*;
import java.io.*;
import java.text.*;
import java.util.*;

import android.graphics.*;

import javax.crypto.spec.*;
import java.security.*;

public class BaseActivity extends AppCompatActivity
{
	private final byte[] ivBytes = {0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00};
	String currentPhotoPath = "";
	
	public File createImageFile() {
		try {
		// Create an image file name
		String timeStamp = new SimpleDateFormat("yyyyMMdd_HHmmss").format(new Date());
		String imageFileName = "JPEG_" + timeStamp + "_";
		File storageDir = getExternalFilesDir(Environment.DIRECTORY_PICTURES);
		File image = File.createTempFile(
			imageFileName,  /* prefix */
			".jpg",         /* suffix */
			storageDir      /* directory */
		);
		// Save a file: path for use with ACTION_VIEW intents
		currentPhotoPath = image.getAbsolutePath();
		return image;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}
	
	public ProgressDialog createDialog(String message) {
		return Util.createDialog(this, message);
	}
	
	public ProgressDialog createDialog(int message) {
		return Util.createDialog(this, message);
	}
	
	public void run(Runnable runnable) {
		Util.run(runnable);
	}
	
	public void runLater(Runnable runnable) {
		Util.runLater(runnable);
	}
	
	public void show(String message) {
		Util.show(this, message);
	}
	
	public void show(int message) {
		Util.show(this, message);
	}
	
	public String read(String name, String defaultValue) {
		return Util.read(this, name, defaultValue);
	}
	
	public void write(String name, String value) {
		Util.write(this, name, value);
	}
	
	public String readEncrypted(String name, String defaultValue) {
		return Util.readEncrypted(this, name, defaultValue);
	}

	public void writeEncrypted(String name, String value) {
		Util.writeEncrypted(this, name, value);
	}
	
	public void b() {}
	
	public Bitmap resizeBitmap(Bitmap image, int maxWidth, int maxHeight) {
		if (maxHeight > 0 && maxWidth > 0) {
			int width = image.getWidth();
			int height = image.getHeight();
			float ratioBitmap = (float) width / (float) height;
			float ratioMax = (float) maxWidth / (float) maxHeight;
			int finalWidth = maxWidth;
			int finalHeight = maxHeight;
			if (ratioMax > ratioBitmap) {
				finalWidth = (int) ((float)maxHeight * ratioBitmap);
			} else {
				finalHeight = (int) ((float)maxWidth / ratioBitmap);
			}
			image = Bitmap.createScaledBitmap(image, finalWidth, finalHeight, true);
			return image;
		} else {
			return image;
		}
	}
	
	private SecretKeySpec generateKey(final String password) throws NoSuchAlgorithmException, UnsupportedEncodingException {
        final MessageDigest digest = MessageDigest.getInstance("SHA-256");
        byte[] bytes = password.getBytes("UTF-8");
        digest.update(bytes, 0, bytes.length);
        byte[] key = digest.digest();
        SecretKeySpec secretKeySpec = new SecretKeySpec(key, "AES");
        return secretKeySpec;
    }
	
	public String encode(String value) {
		return Util.encode(value);
	}
	
	public String decode(String value) {
		return Util.decode(value);
	}
	
	public byte[] decodeToByteArray(byte[] value) {
		return Util.decodeToByteArray(value);
	}
	
	public byte[] encode(byte[] value) {
		return android.util.Base64.encode(value, android.util.Base64.DEFAULT);
	}
	
	public String encodeToString(byte[] value) {
		return android.util.Base64.encodeToString(value, android.util.Base64.DEFAULT);
	}

	public String decode(byte[] value) {
		return new String(android.util.Base64.decode(value, android.util.Base64.DEFAULT));
	}
	
	public byte[] encrypt(byte[] value) {
		return Util.encrypt(value);
	}
	
	public byte[] decrypt(byte[] value) {
		return Util.decrypt(value);
	}
	
	public String encryptString(String value) {
		return Util.encryptString(value);
	}
	
	public String decryptString(String value) {
		return Util.decryptString(value);
	}
}
