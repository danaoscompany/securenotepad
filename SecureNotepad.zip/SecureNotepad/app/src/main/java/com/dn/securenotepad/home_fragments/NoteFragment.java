package com.dn.securenotepad.home_fragments;

import androidx.core.app.*;
import android.view.*;
import android.os.*;
import com.dn.securenotepad.*;
import androidx.appcompat.widget.*;
import java.util.*;
import org.json.*;
import com.dn.securenotepad.adapter.*;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.text.*;
import android.view.View.*;
import android.content.*;
import android.app.Activity;
import androidx.appcompat.app.*;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

public class NoteFragment extends Fragment
{
	private final int ADD_NOTE = 1;
	private final int EDIT_NOTE = 2;
	View view;
	HomeActivity activity;
	RecyclerView noteList;
	ArrayList<JSONObject> notes;
	NoteAdapter adapter;
	FloatingActionButton add;

	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState)
	{
		// TODO: Implement this method
		view = inflater.inflate(R.layout.fragment_note, container, false);
		noteList = view.findViewById(R.id.notes);
		add = view.findViewById(R.id.add);
		return view;
	}

	@Override
	public void onActivityCreated(Bundle savedInstanceState)
	{
		// TODO: Implement this method
		super.onActivityCreated(savedInstanceState);
		activity = (HomeActivity)getActivity();
		noteList.setLayoutManager(new LinearLayoutManager(activity));
		noteList.setItemAnimator(new DefaultItemAnimator());
		notes = new ArrayList<>();
		adapter = new NoteAdapter(activity, notes, new NoteAdapter.Listener() {
			
			@Override
			public void onSelected(int pos, final JSONObject note) {
				new AlertDialog.Builder(activity)
					.setItems(new String[] {
						getResources().getString(R.string.edit),
						getResources().getString(R.string.delete)
					}, new DialogInterface.OnClickListener() {

						@Override
						public void onClick(DialogInterface p1, int pos)
						{
							// TODO: Implement this method
							if (pos == 0) {
								startActivityForResult(new Intent(activity, EditNoteActivity.class)
									.putExtra("note", note.toString()), EDIT_NOTE);
							} else if (pos == 1) {
								new AlertDialog.Builder(activity)
									.setMessage(R.string.text15)
									.setPositiveButton(R.string.yes, new DialogInterface.OnClickListener() {

										@Override
										public void onClick(DialogInterface p1, int p2)
										{
											// TODO: Implement this method
											try {
												JSONArray notesJSON = new JSONArray(activity.read("notes", "[]").trim());
												for (int i=0; i<notesJSON.length(); i++) {
													JSONObject noteJSON = notesJSON.getJSONObject(i);
													if (Util.getString(noteJSON, "uuid", "").trim().equals(
															Util.getString(note, "uuid", "").trim()
														)) {
														notesJSON.remove(i);
														break;
													}
												}
												activity.write("notes", notesJSON.toString());
												getNotes();
											} catch (Exception e) {
												e.printStackTrace();
											}
										}
										
										
									})
									.setNegativeButton(R.string.no, null)
									.create()
									.show();
							}
						}
					})
					.create()
					.show();
			}
		});
		noteList.setAdapter(adapter);
		add.setOnClickListener(new OnClickListener() {

				@Override
				public void onClick(View view) {
					startActivityForResult(new Intent(activity, AddNoteActivity.class), ADD_NOTE);
				}
		});
		getNotes();
	}
	
	public void getNotes() {
		notes.clear();
		adapter.notifyDataSetChanged();
		try {
			JSONArray notesJSON = new JSONArray(activity.read("notes", "[]").trim());
			for (int i=0; i<notesJSON.length(); i++) {
				JSONObject noteJSON = notesJSON.getJSONObject(i);
				notes.add(noteJSON);
			}
			Collections.sort(notes, new Comparator<JSONObject>() {

					@Override
					public int compare(JSONObject note1, JSONObject note2)
					{
						// TODO: Implement this method
						try {
							long date1 = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").parse(Util.getString(note1, "date", "").trim()).getTime();
							long date2 = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").parse(Util.getString(note2, "date", "").trim()).getTime();
							if (date1 < date2) {
								return 1;
							} else if (date1 > date2) {
								return -1;
							} else {
								return 0;
							}
						} catch (Exception e) {
							e.printStackTrace();
						}
						return 0;
					}
					
				
			});
			adapter.notifyDataSetChanged();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Override
	public void onActivityResult(int requestCode, int resultCode, Intent data)
	{
		// TODO: Implement this method
		super.onActivityResult(requestCode, resultCode, data);
		if (resultCode == Activity.RESULT_OK) {
			if (requestCode == ADD_NOTE) {
				getNotes();
			} else if (requestCode == EDIT_NOTE) {
				getNotes();
			}
		}
	}
}
