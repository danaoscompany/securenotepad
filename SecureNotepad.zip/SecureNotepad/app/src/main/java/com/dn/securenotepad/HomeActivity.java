package com.dn.securenotepad;
import android.os.*;
import androidx.appcompat.widget.*;
import android.view.*;

import androidx.core.view.*;
import androidx.core.content.*;
import androidx.appcompat.app.*;
import android.content.*;
import android.widget.EditText;
import android.text.*;

import com.dn.securenotepad.home_fragments.*;
import androidx.core.app.*;
import androidx.fragment.app.Fragment;

public class HomeActivity extends BaseActivity
{
	private final int SAVE_FILE = 1;
	boolean fileListShown = false;
	Menu menu = null;
	HomeFragment homeFragment;
	NoteFragment noteFragment;

	@Override
	protected void onCreate(Bundle savedInstanceState)
	{
		// TODO: Implement this method
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_home);
		setTitle(R.string.text1);
		setSupportActionBar((Toolbar)findViewById(R.id.toolbar));
		homeFragment = new HomeFragment();
		noteFragment = new NoteFragment();
		setFragment(noteFragment);
	}
	
	public void setFragment(Fragment fr) {
		getSupportFragmentManager()
			.beginTransaction()
			.replace(R.id.content, fr)
			.commit();
	}

	public void enterPassword()
	{
		View view = LayoutInflater.from(this).inflate(R.layout.enter_password, null);
		final EditText passwordField = view.findViewById(R.id.password);
		final AlertDialog dialog = new AlertDialog.Builder(HomeActivity.this)
			.setView(view)
			.setPositiveButton(R.string.cancel, null)
			.create();
		passwordField.addTextChangedListener(new TextWatcher() {

				@Override
				public void beforeTextChanged(CharSequence p1, int p2, int p3, int p4)
				{
					// TODO: Implement this method
				}

				@Override
				public void onTextChanged(CharSequence p1, int p2, int p3, int p4)
				{
					// TODO: Implement this method
					final String password = passwordField.getText().toString().trim();
					if (password.startsWith("*") && password.endsWith("#"))
					{
						String currentPassword = readEncrypted("password", "");
						if (currentPassword.equals(password))
						{
							setFragment(homeFragment);
							fileListShown = true;
						}
						else
						{
							show(R.string.text13);
							setFragment(noteFragment);
							fileListShown = false;
						}
						dialog.dismiss();
					}
				}

				@Override
				public void afterTextChanged(Editable p1)
				{
					// TODO: Implement this method
				}
			});
		dialog.show();
	}

	public void setupPassword()
	{
		View view = LayoutInflater.from(this).inflate(R.layout.enter_password, null);
		final EditText passwordField = view.findViewById(R.id.password);
		final AlertDialog dialog = new AlertDialog.Builder(HomeActivity.this)
			.setView(view)
			.setPositiveButton(R.string.cancel, null)
			.create();
		passwordField.addTextChangedListener(new TextWatcher() {

				@Override
				public void beforeTextChanged(CharSequence p1, int p2, int p3, int p4)
				{
					// TODO: Implement this method
				}

				@Override
				public void onTextChanged(CharSequence p1, int p2, int p3, int p4)
				{
					// TODO: Implement this method
					final String password = passwordField.getText().toString().trim();
					if (password.startsWith("*") && password.endsWith("#"))
					{
						dialog.dismiss();
						writeEncrypted("password", password);
						show(R.string.text9);
						setFragment(homeFragment);
						fileListShown = true;
					}
				}

				@Override
				public void afterTextChanged(Editable p1)
				{
					// TODO: Implement this method
				}
			});
		dialog.show();
	}

	public void resetupPassword()
	{
		View view = LayoutInflater.from(this).inflate(R.layout.reenter_password, null);
		final AlertDialog dialog = new AlertDialog.Builder(HomeActivity.this)
			.setView(view)
			.setPositiveButton(R.string.cancel, null)
			.create();
		final EditText passwordField = view.findViewById(R.id.password);
		passwordField.addTextChangedListener(new TextWatcher() {

				@Override
				public void beforeTextChanged(CharSequence p1, int p2, int p3, int p4)
				{
					// TODO: Implement this method
				}

				@Override
				public void onTextChanged(CharSequence p1, int p2, int p3, int p4)
				{
					// TODO: Implement this method
					final String password = passwordField.getText().toString().trim();
					if (password.startsWith("*") && password.endsWith("#"))
					{
						dialog.dismiss();
						String currentPassword = readEncrypted("password", "");
						if (!currentPassword.equals(password))
						{
							show(R.string.text12);
							return;
						}
						setupPassword();
					}
				}

				@Override
				public void afterTextChanged(Editable p1)
				{
					// TODO: Implement this method
				}
			});
		dialog.show();
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu)
	{
		this.menu = menu;
		getMenuInflater().inflate(R.menu.home, menu);
		return true;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item)
	{
 		// TODO: Implement this method
		int id = item.getItemId();
		if (id == android.R.id.home)
		{
			finish();
		}
		else if (id == R.id.password)
		{
			if (fileListShown)
			{
				new AlertDialog.Builder(HomeActivity.this)
					.setMessage(R.string.text11)
					.setPositiveButton(R.string.yes, new DialogInterface.OnClickListener() {

						@Override
						public void onClick(DialogInterface p1, int p2)
						{
							// TODO: Implement this method
							resetupPassword();
						}
					})
					.setNegativeButton(R.string.no, null)
					.create()
					.show();
			}
			else
			{
				String password = readEncrypted("password", "");
				if (password.equals(""))
				{
					new AlertDialog.Builder(HomeActivity.this)
						.setMessage(R.string.text5)
						.setPositiveButton(R.string.ok, new DialogInterface.OnClickListener() {

							@Override
							public void onClick(DialogInterface p1, int p2)
							{
								// TODO: Implement this method
								setupPassword();
							}
						})
						.create()
						.show();
				}
				else
				{
					enterPassword();
				}
			}
		}/* else if (id == R.id.save) {
			Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
			intent.addCategory(Intent.CATEGORY_OPENABLE);
			intent.setType("text/plain");
			intent.putExtra(Intent.EXTRA_TITLE, "NAMA FILE");
			startActivityForResult(intent, SAVE_FILE);
		}*/
		return false;
	}

	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data)
	{
		// TODO: Implement this method
		super.onActivityResult(requestCode, resultCode, data);
		if (resultCode == RESULT_OK) {
			if (requestCode == SAVE_FILE) {
				/*final String text = et.getText().toString();
				if (!text.equals("")) {
					Uri uri = data.getData();
					try {
						OutputStream output = getContentResolver().openOutputStream(uri);
						output.write(text.getBytes());
						output.flush();
						output.close();
						show(R.string.text14);
					}
					catch(IOException e) {
						e.printStackTrace();
					}
				}*/
			}
		}
	}
}
