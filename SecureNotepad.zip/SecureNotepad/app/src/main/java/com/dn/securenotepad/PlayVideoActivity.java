package com.dn.securenotepad;
import android.os.*;
import android.widget.*;
import java.io.*;
import android.net.*;
import android.media.*;
import android.view.*;
import android.app.*;

public class PlayVideoActivity extends BaseActivity
{
	VideoView video;
	String path = "";

	@Override
	protected void onCreate(Bundle savedInstanceState)
	{
		// TODO: Implement this method
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_play_video);
		path = getIntent().getStringExtra("path");
		video = findViewById(R.id.video);
		MediaController mediaController = new MediaController(this);
        mediaController.setAnchorView(video);
        video.setMediaController(mediaController);
		final ProgressDialog dialog = createDialog(R.string.processing);
		dialog.show();
		run(new Runnable() {
			
			@Override
			public void run() {
				try {
					FileInputStream fis = new FileInputStream(new File(path));
					ByteArrayOutputStream baos = new ByteArrayOutputStream();
					int read;
					byte[] buffer = new byte[8192];
					while ((read = fis.read(buffer)) != -1) {
						baos.write(buffer, 0, read);
					}
					baos.flush();
					byte[] encryptedData = baos.toByteArray();
					baos.close();
					fis.close();
					byte[] encodedData = decrypt(encryptedData);
					byte[] data = decodeToByteArray(encodedData);
					final File tmpVideoFile = new File(getFilesDir(), "tmp_video.mp4");
					FileOutputStream fos = new FileOutputStream(tmpVideoFile);
					fos.write(data, 0, data.length);
					fos.flush();
					fos.close();
					runLater(new Runnable() {
						
						@Override
						public void run() {
							dialog.dismiss();
							video.setVideoURI(Uri.fromFile(tmpVideoFile));
							video.setOnPreparedListener(new MediaPlayer.OnPreparedListener() {

									@Override
									public void onPrepared(MediaPlayer player)
									{
										// TODO: Implement this method
										video.start();
									}
							});
						}
					});
				} catch (final Exception e) {
					e.printStackTrace();
					runLater(new Runnable() {

							@Override
							public void run() {
								show(e.getMessage());
							}
						});
				}
			}
		});
	}
}
