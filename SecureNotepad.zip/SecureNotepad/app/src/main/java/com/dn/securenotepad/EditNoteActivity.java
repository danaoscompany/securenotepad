package com.dn.securenotepad;
import android.os.*;
import androidx.appcompat.widget.*;
import android.view.*;
import org.json.*;
import java.text.*;
import java.util.*;

public class EditNoteActivity extends BaseActivity
{
	JSONObject note;
	LinedEditText noteField;

	@Override
	protected void onCreate(Bundle savedInstanceState)
	{
		// TODO: Implement this method
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_edit_note);
		setTitle(R.string.edit_note);
		setSupportActionBar((Toolbar)findViewById(R.id.toolbar));
		getSupportActionBar().setDisplayHomeAsUpEnabled(true);
		try {
			note = new JSONObject(getIntent().getStringExtra("note"));
		} catch (Exception e) {
			e.printStackTrace();
			note = new JSONObject();
		}
		noteField = findViewById(R.id.note);
		noteField.setText(Util.getString(note, "note", ""));
	}

	public void save() {
		final String note = noteField.getText().toString();
		if (note.trim().equals("")) {
			finish();
			return;
		}
		try {
			JSONArray notesJSON = new JSONArray(read("notes", "[]").trim());
			for (int i=0; i<notesJSON.length(); i++) {
				JSONObject noteJSON = notesJSON.getJSONObject(i);
				if (Util.getString(noteJSON, "uuid", "").trim().equals(
					Util.getString(EditNoteActivity.this.note, "uuid", "").trim()
				)) {
					noteJSON.put("note", note);
					noteJSON.put("date", new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(new Date()));
					break;
				}
			}
			write("notes", notesJSON.toString());
			setResult(RESULT_OK);
			finish();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu)
	{
		// TODO: Implement this method
		getMenuInflater().inflate(R.menu.add_note, menu);
		return true;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item)
	{
		// TODO: Implement this method
		int id = item.getItemId();
		if (id == android.R.id.home) {
			save();
		} else if (id == R.id.save) {
			save();
		}
		return false;
	}

	@Override
	public void onBackPressed()
	{
		// TODO: Implement this method
		save();
	}
}
