package com.dn.securenotepad.fragments;

import androidx.core.app.*;
import android.view.*;
import android.os.*;
import com.dn.securenotepad.*;
import androidx.appcompat.app.*;

import android.content.*;
import java.io.*;
import android.net.*;
import androidx.core.content.*;
import android.provider.*;
import android.app.Activity;
import android.graphics.*;
import com.dn.securenotepad.R;
import android.app.ProgressDialog;
import org.json.*;
import java.util.*;
import java.text.*;
import androidx.appcompat.widget.*;
import com.dn.securenotepad.adapter.*;

import android.widget.*;
import android.text.*;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

public class PhotoFragment extends Fragment
{
	HomeActivity activity;
	View view;
	File selectedPictureFile = null;
	private final int TAKE_PICTURE = 1;
	private final int PICK_IMAGE_FROM_GALLERY = 2;
	RecyclerView photoList;
	ArrayList<JSONObject> photos;
	PhotoAdapter adapter;

	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup parent, Bundle savedInstanceState)
	{
		// TODO: Implement this method
		view = inflater.inflate(R.layout.fragment_photo, parent, false);
		return view;
	}

	@Override
	public void onActivityCreated(Bundle savedInstanceState)
	{
		// TODO: Implement this method
		super.onActivityCreated(savedInstanceState);
		activity = (HomeActivity)getActivity();
		photoList = view.findViewById(R.id.photos);
		photoList.setLayoutManager(new GridLayoutManager(activity, 3));
		photoList.setItemAnimator(new DefaultItemAnimator());
		photos = new ArrayList<>();
		try {
			JSONArray photosJSON = new JSONArray(activity.read("photos", "[]").trim());
			for (int i=0; i<photosJSON.length(); i++) {
				photos.add(photosJSON.getJSONObject(i));
			}
			Collections.sort(photos, new Comparator<JSONObject>() {

					@Override
					public int compare(JSONObject photo1, JSONObject photo2) {
						try {
							long date1 = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").parse(Util.getString(photo1, "date", "").trim()).getTime();
							long date2 = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").parse(Util.getString(photo2, "date", "").trim()).getTime();
							if (date1 > date2) {
								return -1;
							} else if (date1 < date2) {
								return 1;
							} else {
								return 0;
							}
						} catch (Exception e) {
							e.printStackTrace();
						}
						return 0;
					}
			});
		} catch (Exception e) {
			e.printStackTrace();
		}
		adapter = new PhotoAdapter(activity, photos);
		photoList.setAdapter(adapter);
	}
	
	public void add() {
		final String currentPassword = activity.readEncrypted("password", "").trim();
		if (currentPassword.equals("")) {
			new AlertDialog.Builder(activity)
				.setMessage(R.string.text5)
				.setPositiveButton(R.string.ok, new DialogInterface.OnClickListener() {

					@Override
					public void onClick(DialogInterface p1, int p2)
					{
						// TODO: Implement this method
						activity.setupPassword();
					}
				})
				.create()
				.show();
			return;
		}
		View view = LayoutInflater.from(activity).inflate(R.layout.enter_password, null);
		final AlertDialog dialog = new AlertDialog.Builder(activity)
			.setView(view)
			.setPositiveButton(R.string.cancel, null)
			.create();
		final EditText passwordField = view.findViewById(R.id.password);
		passwordField.addTextChangedListener(new TextWatcher() {

				@Override
				public void beforeTextChanged(CharSequence p1, int p2, int p3, int p4)
				{
					// TODO: Implement this method
				}

				@Override
				public void onTextChanged(CharSequence p1, int p2, int p3, int p4)
				{
					// TODO: Implement this method
					final String password = passwordField.getText().toString().trim();
					if (password.startsWith("*") && password.endsWith("#")) {
						if (currentPassword.equals(password)) {
							dialog.dismiss();
							AlertDialog dialog = new AlertDialog.Builder(activity)
								.setItems(new String[] {
									getResources().getString(R.string.camera),
									getResources().getString(R.string.gallery)
								}, new DialogInterface.OnClickListener(){

									@Override
									public void onClick(DialogInterface p1, int pos)
									{
										// TODO: Implement this method
										if (pos == 0) {
											selectedPictureFile = activity.createImageFile();
											Intent takePictureIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
											// Ensure that there's a camera activity to handle the intent
											if (takePictureIntent.resolveActivity(activity.getPackageManager()) != null) {
												// Create the File where the photo should go
												// Continue only if the File was successfully created
												if (selectedPictureFile != null) {
													Uri photoURI = FileProvider.getUriForFile(activity, activity.getPackageName()+".fileprovider", selectedPictureFile);
													takePictureIntent.putExtra(MediaStore.EXTRA_OUTPUT, photoURI);
													startActivityForResult(takePictureIntent, TAKE_PICTURE);
												}
											}
										} else if (pos == 1) {
											Intent intent = new Intent();
											intent.setType("image/*");
											intent.setAction(Intent.ACTION_GET_CONTENT);
											startActivityForResult(Intent.createChooser(intent, getResources().getString(R.string.text3)), PICK_IMAGE_FROM_GALLERY);
										}
									}


								})
								.create();
							dialog.show();
						} else {
							activity.show(R.string.text13);
						}
					}
				}

				@Override
				public void afterTextChanged(Editable p1)
				{
					// TODO: Implement this method
				}
		});
		dialog.show();
	}

	@Override
	public void onActivityResult(int requestCode, int resultCode, Intent data)
	{
		// TODO: Implement this method
		super.onActivityResult(requestCode, resultCode, data);
		if (resultCode == Activity.RESULT_OK) {
			if (requestCode == TAKE_PICTURE) {
				final ProgressDialog dialog = activity.createDialog(R.string.processing);
				dialog.show();
				activity.run(new Runnable() {
					
					@Override
					public void run() {
						try {
							String fileName = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(new Date())+".jpg";
							Bitmap b = BitmapFactory.decodeFile(selectedPictureFile.getAbsolutePath());
							savePicture(dialog, fileName, b);
						} catch (final Exception e) {
							e.printStackTrace();
							activity.runLater(new Runnable() {

									@Override
									public void run() {
										dialog.dismiss();
										activity.show(e.getMessage());
									}
								});
						}
					}
				});
			} else if (requestCode == PICK_IMAGE_FROM_GALLERY) {
				try {
					String path = Util.getRealPath(activity, data.getData());
					savePicture(null, path, BitmapFactory.decodeStream(activity.getContentResolver().openInputStream(data.getData())));
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		}
	}
	
	public void savePicture(final ProgressDialog dialog, final String srcPath, Bitmap b) {
		try {
			Bitmap originalBitmap = b;
			originalBitmap = Bitmap.createScaledBitmap(originalBitmap, originalBitmap.getWidth(), originalBitmap.getHeight(), true);
			b = activity.resizeBitmap(b, 100, 100);
			final Bitmap prevBitmap = b;
			b = Util.fastblur(b, 1, 10);
			File previewFolder = new File(activity.getFilesDir(), "preview_photos");
			if (!previewFolder.exists()) {
				previewFolder.mkdirs();
			}
			final Bitmap prevBitmap2 = b;
			/*activity.runLater(new Runnable() {

			 @Override
			 public void run() {
			 if (!prevBitmap2.isRecycled()) {
			 prevBitmap2.recycle();
			 }
			 }
			 });*/
			File previewFile = new File(previewFolder, UUID.randomUUID().toString());
			//File previewFile = new File("/sdcard/blur.png");
			ByteArrayOutputStream baos = new ByteArrayOutputStream();
			originalBitmap.compress(Bitmap.CompressFormat.PNG, 100, baos);
			baos.flush();
			byte[] data = baos.toByteArray();
			baos.close();
			FileOutputStream fos = new FileOutputStream(previewFile);
			b.compress(Bitmap.CompressFormat.PNG, 100, fos);
			fos.flush();
			fos.close();
			byte[] encodedData = activity.encode(data);
			byte[] encryptedData = activity.encrypt(encodedData);
			File encryptedFolder = new File(activity.getFilesDir(), "encrypted_photos");
			if (!encryptedFolder.exists()) {
				encryptedFolder.mkdirs();
			}
			File encryptedFile = new File(encryptedFolder, UUID.randomUUID().toString());
			fos = new FileOutputStream(encryptedFile);
			fos.write(encryptedData);
			fos.flush();
			fos.close();
			/*if (!b.isRecycled()) {
			 b.recycle();
			 }*/
			
			/* FOR TEST ONLY
			try {
				File f = new File(Environment.getExternalStorageDirectory(), "img1.jpg");
				b = BitmapFactory.decodeFile(f.getAbsolutePath());
				baos = new ByteArrayOutputStream();
				b.compress(Bitmap.CompressFormat.PNG, 100, baos);
				if (!b.isRecycled()) {
					b.recycle();
				}
				baos.flush();
				byte[] data = baos.toByteArray();
				baos.close();
				String encodedData = activity.encode(data);
				String encryptedData = activity.encrypt(encodedData);
				encryptedFile.delete();
				encryptedFile = new File(encryptedFolder, UUID.randomUUID().toString());
				fos = new FileOutputStream(encryptedFile);
				fos.write(encryptedData.getBytes());
				fos.flush();
				fos.close();
			} catch (final Exception e) {
				e.printStackTrace();
				activity.runLater(new Runnable() {

						@Override
						public void run() {
							dialog.dismiss();
							activity.show(e.getMessage());
						}
					});
			}*/
			 
			JSONArray photos = new JSONArray(activity.read("photos", "[]"));
			final JSONObject photo = new JSONObject();
			photo.put("src_path", srcPath);
			photo.put("path", encryptedFile.getAbsolutePath());
			photo.put("preview_path", previewFile.getAbsolutePath());
			photo.put("date", new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(new Date()));
			photos.put(photo);
			activity.write("photos", photos.toString());
			try {
				if (!originalBitmap.isRecycled()) {
					originalBitmap.recycle();
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
			new File(srcPath).delete();
			Util.refreshDeleteFile(activity, new File(srcPath));
			activity.runLater(new Runnable() {

					@Override
					public void run() {
						PhotoFragment.this.photos.add(0, photo);
						adapter.notifyDataSetChanged();
						if (dialog != null) {
							dialog.dismiss();
						}
						activity.show(R.string.text2);
					}
				});
		} catch (final Exception e) {
			e.printStackTrace();
			activity.runLater(new Runnable() {

					@Override
					public void run() {
						if (dialog != null) {
							dialog.dismiss();
						}
						activity.show(e.getMessage());
					}
				});
		}
	}
	
	public void b() {}
}
