package com.dn.securenotepad.adapter;

import androidx.appcompat.widget.*;
import android.view.*;
import android.content.*;
import java.util.*;
import org.json.*;
import com.dn.securenotepad.R;
import android.widget.*;
import java.io.*;
import com.dn.securenotepad.*;

import androidx.appcompat.app.*;
import android.text.*;
import android.app.ProgressDialog;

import androidx.recyclerview.widget.RecyclerView;

public class PhotoAdapter extends RecyclerView.Adapter<PhotoAdapter.ViewHolder> {
	public Context context;
	public ArrayList<JSONObject> photos;
	
	public PhotoAdapter(Context ctx, ArrayList<JSONObject> photos) {
		this.context = ctx;
		this.photos = photos;
	}
	
	@Override
	public PhotoAdapter.ViewHolder onCreateViewHolder(ViewGroup parent, int p2)
	{
		// TODO: Implement this method
		return new ViewHolder(LayoutInflater.from(context).inflate(R.layout.photo, parent, false));
	}

	@Override
	public void onBindViewHolder(PhotoAdapter.ViewHolder holder, final int position)
	{
		// TODO: Implement this method
		try {
			final JSONObject photo = photos.get(position);
			holder.select.setOnClickListener(new View.OnClickListener() {
				
				@Override
				public void onClick(View view) {
					new AlertDialog.Builder(context)
						.setItems(new String[] {
							context.getResources().getString(R.string.view),
							context.getResources().getString(R.string.restore),
							context.getResources().getString(R.string.delete)
						}, new DialogInterface.OnClickListener() {
							
							@Override
							public void onClick(DialogInterface dialogInterface, int pos) {
								if (pos == 0) {
									Intent i = new Intent(context, ViewImageActivity.class);
									i.putExtra("path", Util.getString(photo, "path", "").trim());
									context.startActivity(i);
									/*final String currentPassword = Util.readEncrypted(context, "password", "").trim();
									if (currentPassword.equals("")) {
										new AlertDialog.Builder(context)
											.setMessage(R.string.text5)
											.setPositiveButton(R.string.ok, new DialogInterface.OnClickListener() {

												@Override
												public void onClick(DialogInterface p1, int p2)
												{
													// TODO: Implement this method
													((HomeActivity)context).setupPassword();
												}
											})
											.create()
											.show();
										return;
									}
									View view = LayoutInflater.from(context).inflate(R.layout.enter_password, null);
									final AlertDialog dialog = new AlertDialog.Builder(context)
										.setView(view)
										.setPositiveButton(R.string.cancel, null)
										.create();
									final EditText passwordField = view.findViewById(R.id.password);
									passwordField.addTextChangedListener(new TextWatcher() {

											@Override
											public void beforeTextChanged(CharSequence p1, int p2, int p3, int p4)
											{
												// TODO: Implement this method
											}

											@Override
											public void onTextChanged(CharSequence p1, int p2, int p3, int p4)
											{
												// TODO: Implement this method
												final String password = passwordField.getText().toString().trim();
												if (password.startsWith("*") && password.endsWith("#")) {
													dialog.dismiss();
													if (currentPassword.equals(password)) {
														Intent i = new Intent(context, ViewImageActivity.class);
														i.putExtra("path", Util.getString(photo, "path", "").trim());
														context.startActivity(i);
													} else {
														Util.show(context, R.string.text13);
													}
												}
											}

											@Override
											public void afterTextChanged(Editable p1)
											{
												// TODO: Implement this method
											}
										});
									dialog.show();*/
								} else if (pos == 1) {
									new AlertDialog.Builder(context)
										.setMessage(R.string.text16)
										.setPositiveButton(R.string.yes, new DialogInterface.OnClickListener() {

											@Override
											public void onClick(DialogInterface p1, int p2)
											{
												// TODO: Implement this method
												final String currentPassword = Util.readEncrypted(context, "password", "").trim();
												if (currentPassword.equals("")) {
													new AlertDialog.Builder(context)
														.setMessage(R.string.text5)
														.setPositiveButton(R.string.ok, new DialogInterface.OnClickListener() {

															@Override
															public void onClick(DialogInterface p1, int p2)
															{
																// TODO: Implement this method
																((HomeActivity)context).setupPassword();
															}
														})
														.create()
														.show();
													return;
												}
												View view = LayoutInflater.from(context).inflate(R.layout.enter_password, null);
												final AlertDialog dialog = new AlertDialog.Builder(context)
													.setView(view)
													.setPositiveButton(R.string.cancel, null)
													.create();
												final EditText passwordField = view.findViewById(R.id.password);
												passwordField.addTextChangedListener(new TextWatcher() {

														@Override
														public void beforeTextChanged(CharSequence p1, int p2, int p3, int p4)
														{
															// TODO: Implement this method
														}

														@Override
														public void onTextChanged(CharSequence p1, int p2, int p3, int p4)
														{
															// TODO: Implement this method
															final String password = passwordField.getText().toString().trim();
															if (password.startsWith("*") && password.endsWith("#")) {
																dialog.dismiss();
																if (currentPassword.equals(password)) {
																	final ProgressDialog dialog = Util.createDialog(context, R.string.processing);
																	dialog.show();
																	Util.run(new Runnable() {

																		@Override
																		public void run() {
																			try {
																				File file = new File(Util.getString(photo, "path", "").trim());
																				FileInputStream fis = new FileInputStream(file);
																				ByteArrayOutputStream baos = new ByteArrayOutputStream();
																				int read;
																				byte[] buffer = new byte[8192];
																				while ((read = fis.read(buffer)) != -1) {
																					baos.write(buffer, 0, read);
																				}
																				baos.flush();
																				byte[] encryptedData = baos.toByteArray();
																				baos.close();
																				byte[] encodedData = Util.decrypt(encryptedData);
																				byte[] data = Util.decodeToByteArray(encodedData);
																				File srcFile = new File(Util.getString(photo, "src_path", "").trim());
																				FileOutputStream fos = new FileOutputStream(srcFile);
																				fos.write(data);
																				fos.flush();
																				fos.close();
																				Util.refreshAddFile(context, srcFile);
																				Util.runLater(new Runnable() {

																						@Override
																						public void run() {
																							photos.remove(position);
																							notifyItemRemoved(position);
																							try {
																								JSONArray photosJSON = new JSONArray();
																								for (JSONObject photo:photos) {
																									photosJSON.put(photo);
																								}
																								Util.write(context, "photos", photosJSON.toString());
																							} catch (Exception e) {
																								e.printStackTrace();
																							}
																							dialog.dismiss();
																						}
																					});
																			} catch (final Exception e) {
																				e.printStackTrace();
																				Util.runLater(new Runnable() {

																					@Override
																					public void run() {
																						Util.show(context, e.getMessage());
																					}
																				});
																			}
																		}
																	});
																} else {
																	Util.show(context, R.string.text13);
																}
															}
														}

														@Override
														public void afterTextChanged(Editable p1)
														{
															// TODO: Implement this method
														}
													});
												dialog.show();
											}
										})
										.setNegativeButton(R.string.no, null)
										.create()
										.show();
								} else if (pos == 2) {
									new AlertDialog.Builder(context)
										.setMessage(R.string.text4)
										.setPositiveButton(R.string.yes, new DialogInterface.OnClickListener() {

											@Override
											public void onClick(DialogInterface p1, int p2)
											{
												// TODO: Implement this method
												final String currentPassword = Util.readEncrypted(context, "password", "").trim();
												if (currentPassword.equals("")) {
													new AlertDialog.Builder(context)
														.setMessage(R.string.text5)
														.setPositiveButton(R.string.ok, new DialogInterface.OnClickListener() {

															@Override
															public void onClick(DialogInterface p1, int p2)
															{
																// TODO: Implement this method
																((HomeActivity)context).setupPassword();
															}
														})
														.create()
														.show();
													return;
												}
												View view = LayoutInflater.from(context).inflate(R.layout.enter_password, null);
												final AlertDialog dialog = new AlertDialog.Builder(context)
													.setView(view)
													.setPositiveButton(R.string.cancel, null)
													.create();
												final EditText passwordField = view.findViewById(R.id.password);
												passwordField.addTextChangedListener(new TextWatcher() {

														@Override
														public void beforeTextChanged(CharSequence p1, int p2, int p3, int p4)
														{
															// TODO: Implement this method
														}

														@Override
														public void onTextChanged(CharSequence p1, int p2, int p3, int p4)
														{
															// TODO: Implement this method
															final String password = passwordField.getText().toString().trim();
															if (password.startsWith("*") && password.endsWith("#")) {
																dialog.dismiss();
																if (currentPassword.equals(password)) {
																	photos.remove(position);
																	notifyItemRemoved(position);
																	try {
																		JSONArray photosJSON = new JSONArray();
																		for (JSONObject photo:photos) {
																			photosJSON.put(photo);
																		}
																		Util.write(context, "photos", photosJSON.toString());
																	} catch (Exception e) {
																		e.printStackTrace();
																	}
																} else {
																	Util.show(context, R.string.text13);
																}
															}
														}

														@Override
														public void afterTextChanged(Editable p1)
														{
															// TODO: Implement this method
														}
													});
												dialog.show();
											}
										})
										.setNegativeButton(R.string.no, null)
										.create()
										.show();
								}
							}
						})
						.create()
						.show();
				}
			});
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Override
	public int getItemCount()
	{
		// TODO: Implement this method
		return photos.size();
	}
	
	public class ViewHolder extends RecyclerView.ViewHolder {
		public LinearLayout select;

		public ViewHolder(View view) {
			super(view);
			select = view.findViewById(R.id.select);
		}
	}
	
	public void b() {}
}
