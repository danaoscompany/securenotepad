package com.dn.securenotepad.fragments;

import androidx.core.app.*;
import android.view.*;
import android.os.*;
import com.dn.securenotepad.*;
import androidx.appcompat.app.*;
import android.content.*;
import android.app.Activity;
import android.app.ProgressDialog;
import java.io.*;
import java.util.*;
import org.json.*;
import java.text.*;
import androidx.appcompat.widget.*;
import com.dn.securenotepad.adapter.*;
import android.widget.EditText;
import android.text.*;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

public class VideoFragment extends Fragment
{
	HomeActivity activity;
	View view;
	private final int PICK_VIDEO_FROM_GALLERY = 1;
	RecyclerView videoList;
	ArrayList<JSONObject> videos;
	VideoAdapter adapter;

	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup parent, Bundle savedInstanceState)
	{
		// TODO: Implement this method
		view = inflater.inflate(R.layout.fragment_video, parent, false);
		return view;
	}

	@Override
	public void onActivityCreated(Bundle savedInstanceState)
	{
		// TODO: Implement this method
		super.onActivityCreated(savedInstanceState);
		activity = (HomeActivity)getActivity();
		videoList = view.findViewById(R.id.videos);
		videoList.setLayoutManager(new GridLayoutManager(activity, 3));
		videoList.setItemAnimator(new DefaultItemAnimator());
		videos = new ArrayList<>();
		try {
			JSONArray photosJSON = new JSONArray(activity.read("videos", "[]").trim());
			for (int i=0; i<photosJSON.length(); i++) {
				videos.add(photosJSON.getJSONObject(i));
			}
			Collections.sort(videos, new Comparator<JSONObject>() {

					@Override
					public int compare(JSONObject photo1, JSONObject photo2) {
						try {
							long date1 = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").parse(Util.getString(photo1, "date", "").trim()).getTime();
							long date2 = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").parse(Util.getString(photo2, "date", "").trim()).getTime();
							if (date1 > date2) {
								return -1;
							} else if (date1 < date2) {
								return 1;
							} else {
								return 0;
							}
						} catch (Exception e) {
							e.printStackTrace();
						}
						return 0;
					}
				});
		} catch (Exception e) {
			e.printStackTrace();
		}
		adapter = new VideoAdapter(activity, videos);
		videoList.setAdapter(adapter);
	}
	
	public void add() {
		final String currentPassword = activity.readEncrypted("password", "").trim();
		if (currentPassword.equals("")) {
			new AlertDialog.Builder(activity)
				.setMessage(R.string.text5)
				.setPositiveButton(R.string.ok, new DialogInterface.OnClickListener() {

					@Override
					public void onClick(DialogInterface p1, int p2)
					{
						// TODO: Implement this method
						activity.setupPassword();
					}
				})
				.create()
				.show();
			return;
		}
		View view = LayoutInflater.from(activity).inflate(R.layout.enter_password, null);
		final EditText passwordField = view.findViewById(R.id.password);
		passwordField.addTextChangedListener(new TextWatcher() {

				@Override
				public void beforeTextChanged(CharSequence p1, int p2, int p3, int p4)
				{
					// TODO: Implement this method
				}

				@Override
				public void onTextChanged(CharSequence p1, int p2, int p3, int p4)
				{
					// TODO: Implement this method
					final String password = passwordField.getText().toString().trim();
					if (password.startsWith("*") && password.endsWith("#")) {
						if (currentPassword.equals(password)) {
							Intent intent = new Intent();
							intent.setType("video/*");
							intent.setAction(Intent.ACTION_GET_CONTENT);
							startActivityForResult(Intent.createChooser(intent, getResources().getString(R.string.text3)), PICK_VIDEO_FROM_GALLERY);
						} else {
							activity.show(R.string.text13);
						}
					}
				}

				@Override
				public void afterTextChanged(Editable p1)
				{
					// TODO: Implement this method
				}
			});
		new AlertDialog.Builder(activity)
			.setView(view)
			.setPositiveButton(R.string.cancel, null)
			.create()
			.show();
	}

	@Override
	public void onActivityResult(int requestCode, int resultCode, final Intent data)
	{
		// TODO: Implement this method
		super.onActivityResult(requestCode, resultCode, data);
		if (resultCode == Activity.RESULT_OK) {
			if (requestCode == PICK_VIDEO_FROM_GALLERY) {
				final ProgressDialog dialog = activity.createDialog(R.string.processing);
				dialog.show();
				activity.run(new Runnable() {
					
					@Override
					public void run() {
						try {
							String path = Util.getRealPath(activity, data.getData());
							InputStream stream = activity.getContentResolver().openInputStream(data.getData());
							ByteArrayOutputStream baos = new ByteArrayOutputStream();
							int read;
							byte[] buffer = new byte[8192];
							while ((read = stream.read(buffer)) != -1) {
								baos.write(buffer, 0, read);
							}
							baos.flush();
							byte[] data = baos.toByteArray();
							baos.close();
							stream.close();
							byte[] encodedData = activity.encode(data);
							byte[] encryptedData = activity.encrypt(encodedData);
							File encryptedFolder = new File(activity.getFilesDir(), "encrypted_videos");
							if (!encryptedFolder.exists()) {
								encryptedFolder.mkdirs();
							}
							File encryptedFile = new File(encryptedFolder, UUID.randomUUID().toString());
							FileOutputStream fos = new FileOutputStream(encryptedFile);
							fos.write(encryptedData);
							fos.flush();
							fos.close();
							JSONArray videos = new JSONArray(activity.read("photos", "[]"));
							final JSONObject video = new JSONObject();
							video.put("path", encryptedFile.getAbsolutePath());
							video.put("date", new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(new Date()));
							video.put("src_path", path);
							videos.put(video);
							new File(path).delete();
							Util.refreshDeleteFile(activity, new File(path));
							activity.write("videos", videos.toString());
							activity.runLater(new Runnable() {
								
								@Override
								public void run() {
									VideoFragment.this.videos.add(0, video);
									adapter.notifyDataSetChanged();
									dialog.dismiss();
								}
							});
						} catch (final Exception e) {
							e.printStackTrace();
							activity.runLater(new Runnable() {

									@Override
									public void run() {
										activity.show(e.getMessage());
									}
								});
						}
					}
				});
			}
		}
	}
}
