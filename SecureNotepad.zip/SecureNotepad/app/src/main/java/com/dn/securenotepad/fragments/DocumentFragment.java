package com.dn.securenotepad.fragments;

import androidx.core.app.*;
import android.view.*;
import android.os.*;
import com.dn.securenotepad.*;
import androidx.appcompat.app.*;
import android.content.*;
import android.app.Activity;
import android.app.ProgressDialog;
import java.io.*;
import java.util.*;
import org.json.*;
import java.text.*;
import androidx.appcompat.widget.*;
import com.dn.securenotepad.adapter.*;
import android.widget.EditText;
import android.text.*;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

public class DocumentFragment extends Fragment
{
	HomeActivity activity;
	View view;
	private final int PICK_DOCUMENT_FROM_GALLERY = 1;
	RecyclerView documentList;
	ArrayList<JSONObject> documents;
	DocumentAdapter adapter;

	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup parent, Bundle savedInstanceState)
	{
		// TODO: Implement this method
		view = inflater.inflate(R.layout.fragment_document, parent, false);
		return view;
	}

	@Override
	public void onActivityCreated(Bundle savedInstanceState)
	{
		// TODO: Implement this method
		super.onActivityCreated(savedInstanceState);
		activity = (HomeActivity)getActivity();
		documentList = view.findViewById(R.id.documents);
		documentList.setLayoutManager(new GridLayoutManager(activity, 3));
		documentList.setItemAnimator(new DefaultItemAnimator());
		documents = new ArrayList<>();
		try {
			JSONArray documentsJSON = new JSONArray(activity.read("documents", "[]").trim());
			for (int i=0; i<documentsJSON.length(); i++) {
				documents.add(documentsJSON.getJSONObject(i));
			}
			Collections.sort(documents, new Comparator<JSONObject>() {

					@Override
					public int compare(JSONObject document1, JSONObject document2) {
						try {
							long date1 = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").parse(Util.getString(document1, "date", "").trim()).getTime();
							long date2 = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").parse(Util.getString(document2, "date", "").trim()).getTime();
							if (date1 > date2) {
								return -1;
							} else if (date1 < date2) {
								return 1;
							} else {
								return 0;
							}
						} catch (Exception e) {
							e.printStackTrace();
						}
						return 0;
					}
				});
		} catch (Exception e) {
			e.printStackTrace();
		}
		adapter = new DocumentAdapter(activity, documents);
		documentList.setAdapter(adapter);
	}

	public void add() {
		final String currentPassword = activity.readEncrypted("password", "").trim();
		if (currentPassword.equals("")) {
			new AlertDialog.Builder(activity)
				.setMessage(R.string.text5)
				.setPositiveButton(R.string.ok, new DialogInterface.OnClickListener() {

					@Override
					public void onClick(DialogInterface p1, int p2)
					{
						// TODO: Implement this method
						activity.setupPassword();
					}
				})
				.create()
				.show();
			return;
		}
		View view = LayoutInflater.from(activity).inflate(R.layout.enter_password, null);
		final AlertDialog dialog = new AlertDialog.Builder(activity)
			.setView(view)
			.setPositiveButton(R.string.cancel, null)
			.create();
		final EditText passwordField = view.findViewById(R.id.password);
		passwordField.addTextChangedListener(new TextWatcher() {

				@Override
				public void beforeTextChanged(CharSequence p1, int p2, int p3, int p4)
				{
					// TODO: Implement this method
				}

				@Override
				public void onTextChanged(CharSequence p1, int p2, int p3, int p4)
				{
					// TODO: Implement this method
					final String password = passwordField.getText().toString().trim();
					if (password.startsWith("*") && password.endsWith("#")) {
						if (currentPassword.equals(password)) {
							dialog.dismiss();
							Intent intent = new Intent();
							intent.setType("*/*");
							intent.setAction(Intent.ACTION_GET_CONTENT);
							startActivityForResult(Intent.createChooser(intent, getResources().getString(R.string.text3)), PICK_DOCUMENT_FROM_GALLERY);
						} else {
							activity.show(R.string.text13);
						}
					}
				}

				@Override
				public void afterTextChanged(Editable p1)
				{
					// TODO: Implement this method
				}
			});
		dialog.show();
	}

	@Override
	public void onActivityResult(int requestCode, int resultCode, final Intent data)
	{
		// TODO: Implement this method
		super.onActivityResult(requestCode, resultCode, data);
		if (resultCode == Activity.RESULT_OK) {
			if (requestCode == PICK_DOCUMENT_FROM_GALLERY) {
				final ProgressDialog dialog = activity.createDialog(R.string.processing);
				dialog.show();
				activity.run(new Runnable() {

						@Override
						public void run() {
							try {
								String path = Util.getRealPath(activity, data.getData());
								final String mimeType = activity.getContentResolver().getType(data.getData());
								InputStream stream = activity.getContentResolver().openInputStream(data.getData());
								ByteArrayOutputStream baos = new ByteArrayOutputStream();
								int read;
								byte[] buffer = new byte[8192];
								while ((read = stream.read(buffer)) != -1) {
									baos.write(buffer, 0, read);
								}
								baos.flush();
								byte[] data = baos.toByteArray();
								baos.close();
								stream.close();
								byte[] encodedData = activity.encode(data);
								byte[] encryptedData = activity.encrypt(encodedData);
								File encryptedFolder = new File(activity.getFilesDir(), "encrypted_documents");
								if (!encryptedFolder.exists()) {
									encryptedFolder.mkdirs();
								}
								File encryptedFile = new File(encryptedFolder, UUID.randomUUID().toString());
								FileOutputStream fos = new FileOutputStream(encryptedFile);
								fos.write(encryptedData);
								fos.flush();
								fos.close();
								JSONArray documents = new JSONArray(activity.read("documents", "[]"));
								final JSONObject document = new JSONObject();
								document.put("path", encryptedFile.getAbsolutePath());
								document.put("date", new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(new Date()));
								document.put("mime_type", mimeType);
								documents.put(document);
								new File(path).delete();
								Util.refreshDeleteFile(activity, new File(path));
								activity.write("documents", documents.toString());
								activity.runLater(new Runnable() {

										@Override
										public void run() {
											DocumentFragment.this.documents.add(0, document);
											adapter.notifyDataSetChanged();
											dialog.dismiss();
										}
									});
							} catch (final Exception e) {
								e.printStackTrace();
								activity.runLater(new Runnable() {

										@Override
										public void run() {
											activity.show(e.getMessage());
										}
									});
							}
						}
					});
			}
		}
	}
}
