package com.dn.securenotepad;
import android.os.*;
import android.widget.*;
import java.io.*;
import android.graphics.*;
import com.bumptech.glide.*;

public class ViewImageActivity extends BaseActivity
{
	String path = "";
	ImageView imgView;

	@Override
	protected void onCreate(Bundle savedInstanceState)
	{
		// TODO: Implement this method
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_view_image);
		path = getIntent().getStringExtra("path");
		imgView = findViewById(R.id.img);
		try {
			File file = new File(path);
			FileInputStream fis = new FileInputStream(file);
			ByteArrayOutputStream baos = new ByteArrayOutputStream();
			int read;
			byte[] buffer = new byte[8192];
			while ((read = fis.read(buffer)) != -1) {
				baos.write(buffer, 0, read);
			}
			baos.flush();
			byte[] encryptedData = baos.toByteArray();
			baos.close();
			byte[] encodedData = decrypt(encryptedData);
			byte[] data = decodeToByteArray(encodedData);
			Glide.with(this).load(data).into(imgView);
		} catch (Exception e) {
			e.printStackTrace();
			show(e.getMessage());
		}
		//test();
	}
	
	public void test() {
		try {
			File f = new File(Environment.getExternalStorageDirectory(), "img1.jpg");
			Bitmap b = BitmapFactory.decodeFile(f.getAbsolutePath());
			ByteArrayOutputStream baos = new ByteArrayOutputStream();
			b.compress(Bitmap.CompressFormat.PNG, 100, baos);
			if (!b.isRecycled()) {
				b.recycle();
			}
			baos.flush();
			byte[] data = baos.toByteArray();
			baos.close();
			byte[] encodedData = encode(data);
			byte[] encryptedData = encrypt(encodedData);
			encodedData = decrypt(encryptedData);
			data = decodeToByteArray(encodedData);
			imgView.setImageBitmap(BitmapFactory.decodeByteArray(data, 0, data.length));
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
