package com.dn.securenotepad.adapter;
import androidx.core.app.*;
import java.util.*;
import android.content.*;

import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentPagerAdapter;

public class ViewPagerAdapter extends FragmentPagerAdapter
{
	public Context context;
	public ArrayList<Fragment> fragments;
	public ArrayList<String> fragmentTitles;
	
	public ViewPagerAdapter(Context ctx, FragmentManager fm) {
		super(fm);
		context = ctx;
		fragments = new ArrayList<>();
		fragmentTitles = new ArrayList<>();
	}
	
	public void add(Fragment fr, String title) {
		fragments.add(fr);
		fragmentTitles.add(title);
	}
	
	public void add(Fragment fr, int title) {
		fragments.add(fr);
		fragmentTitles.add(context.getResources().getString(title));
	}

	@Override
	public Fragment getItem(int pos)
	{
		// TODO: Implement this method
		return fragments.get(pos);
	}

	@Override
	public int getCount()
	{
		// TODO: Implement this method
		return fragments.size();
	}

	@Override
	public CharSequence getPageTitle(int pos)
	{
		// TODO: Implement this method
		return fragmentTitles.get(pos);
	}
	
	public void b() {}
}
